﻿namespace MyVaccine.WebApi.Dtos.Dependent
{
    public class DependentResponseDto : DependentRequestDto
    {
        public int Id { get; set; }
    }
}
