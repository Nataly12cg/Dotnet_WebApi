﻿namespace MyVaccine.WebApi.Dtos.Allergy
{
    public class AllergyResponseDto : AllergyRequestDto
    {
        public int Id { get; set; }
    }
}
