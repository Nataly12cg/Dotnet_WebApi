﻿namespace MyVaccine.WebApi.Dtos.Vaccine
{
    public class VaccineResponseDto : VaccineRequestDto
    {
        public int Id { get; set; }
    }
}
