﻿namespace MyVaccine.WebApi.Dtos.VaccineRecord
{
    public class VaccineRecordResponseDto : VaccineRecordRequestDto
    {
        public int Id { get; set; }
    }
}
