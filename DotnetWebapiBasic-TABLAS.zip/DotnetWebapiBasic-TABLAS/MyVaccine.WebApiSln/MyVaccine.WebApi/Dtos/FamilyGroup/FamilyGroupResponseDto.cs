﻿namespace MyVaccine.WebApi.Dtos.FamilyGroup
{
    public class FamilyGroupResponseDto: FamilyGroupRequestDto
    {
        public int Id { get; set; }
    }
}
