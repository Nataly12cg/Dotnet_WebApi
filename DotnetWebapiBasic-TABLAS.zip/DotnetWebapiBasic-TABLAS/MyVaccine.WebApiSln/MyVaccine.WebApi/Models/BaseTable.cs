﻿namespace MyVaccine.WebApi.Models
{
    public class BaseTable
    {
        public DateTime? CreatedAt { get; set; }
        public DateTime? UpdatedAt { get; set; }
    }
}
