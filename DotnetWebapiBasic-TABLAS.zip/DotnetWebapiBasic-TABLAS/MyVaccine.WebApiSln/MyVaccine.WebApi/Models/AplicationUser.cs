﻿using Microsoft.AspNetCore.Identity;

namespace MyVaccine.WebApi.Models
{
    public class AplicationUser : IdentityUser
    {
    }
}
